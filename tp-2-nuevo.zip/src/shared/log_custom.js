export function logPurple(message) {
    console.log(`\x1b[35m%s\x1b[0m`, `💜denu ${message}
--------------------------------------------------`);;
}

export function logCyan(message) {
    console.log(`\x1b[36m%s\x1b[0m`, `💎denu ${message}
--------------------------------------------------`);
}

