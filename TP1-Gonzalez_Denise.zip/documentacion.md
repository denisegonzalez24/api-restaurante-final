# README

## comandos

```bash

npm i
npm run db:sync 

npm run db:seed

npm start      


