// src/container/index.js
import { models } from "../infrastructure/db/sequelize.js";

/* ============ DISH ============ */
import { dishQueryRepository } from "../infrastructure/query/dish.query.js";
import { dishCommandRepository } from "../infrastructure/command/dish.command.js";
import { makeDishController } from "../presentation/controllers/dish.controller.js";
import { makeDishRoutes } from "../presentation/routes/dish.routes.js";
// Casos de uso de Dish (ajustá rutas si difieren en tu proyecto)
import { makeCreateDish } from "../application/dish_service/createDish.command.js";
import { makeUpdateDish } from "../application/dish_service/updateDish.command.js";
import { makeListDishes } from "../application/dish_service/listDishes.query.js";

/* ============ CATALOG (opcional) ============ */
import { categoryQueryRepository } from "../infrastructure/query/category.query.js";
import { deliveryTypeQueryRepository } from "../infrastructure/query/deliveryType.query.js";
import { statusQueryRepository } from "../infrastructure/query/status.query.js";
import { makeCatalogController } from "../presentation/controllers/catalog.controller.js";
import { makeCatalogRoutes } from "../presentation/routes/catalog.routes.js";

/* ============ ORDER (opcional) ============ */
import { orderQueryRepository } from "../infrastructure/query/order.query.js";
import { orderCommandRepository } from "../infrastructure/command/order.command.js";
import { makeOrderController } from "../presentation/controllers/order.controller.js";
import { makeOrderRoutes } from "../presentation/routes/order.routes.js";

export function buildContainer() {
    /* --- Dish --- */
    const dishQueryRepo = dishQueryRepository({ models });
    const dishCommandRepo = dishCommandRepository({ models });

    const createDish = makeCreateDish({ dishCommandRepo, dishQueryRepo });
    const updateDish = makeUpdateDish({ dishCommandRepo, dishQueryRepo });
    const listDishes = makeListDishes({ dishQueryRepo });

    const dishController = makeDishController({ createDish, updateDish, listDishes });
    const dishRouter = makeDishRoutes(dishController); // <- Router válido

    /* --- Catalog (si existen los archivos) --- */
    let catalogRouter = null;
    try {
        const categoryQueryRepo = categoryQueryRepository({ models });
        const deliveryTypeQueryRepo = deliveryTypeQueryRepository({ models });
        const statusQueryRepo = statusQueryRepository({ models });

        const catalogController = makeCatalogController({
            categoryQueryRepo,
            deliveryTypeQueryRepo,
            statusQueryRepo,
        });
        catalogRouter = makeCatalogRoutes(catalogController);
    } catch (err) {
        console.warn("[Container] Catalog no montado:", err?.message);
    }

    /* --- Order (si existen los archivos) --- */
    let orderRouter = null;
    try {
        const _orderQueryRepo = orderQueryRepository({ models });
        const _orderCommandRepo = orderCommandRepository({ models });

        // ⚠️ Evitá exponer models al controller. Mejor: si tu controller necesitaba OrderItem,
        // agregá un método en el repo: _orderQueryRepo.findItemById = (id) => ...
        const orderController = makeOrderController({
            orderQueryRepo: _orderQueryRepo,
            orderCommandRepo: _orderCommandRepo,
        });
        orderRouter = makeOrderRoutes(orderController);
    } catch (err) {
        console.warn("[Container] Order no montado:", err?.message);
    }

    return {
        routers: {
            dish: dishRouter,      // ¡Este es el importante para que no crashee!
            catalog: catalogRouter,
            order: orderRouter,
        },
    };
}
