export class CategoryRepository {
    async findById(id) { throw new Error('not implemented'); }
    async existsById(id) { throw new Error('not implemented'); }
}